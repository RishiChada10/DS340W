# paper_forester/

The modelling code of Cavus & Biecek (2022), made to run on R 4.3 with current
packages. Loaded by `paper_setup.R`; nothing here is run directly.

| file | source | modified |
|---|---|---|
| `original/*.R` | `Changes/` folder of github.com/mcavs/Explainable_xG_model_paper | no, byte-for-byte |
| `evaluate.R`, `forester.R`, `make_*.R`, `model_performancex.R` | same seven files | yes, 9 patches marked `DS340W PATCH n` |
| `forester_*.R` | github.com/ModelOriented/forester @ `4813a95` (2022-03-11) | no |

forester had no commits between 2022-03-11 and 2022-08-21, so `4813a95` is the
version current when the paper's `Rcodes.Rmd` was written (June 2022).

Every change is in `../PAPER_PATCHES.diff`. In short:

| # | file | why |
|---|---|---|
| 1 | forester.R | `if (class(x) == "try-error")` errors on R >= 4.2 (fixed the same way upstream in Aug 2022) |
| 2 | forester.R | print the real error; upstream reports every failure as "package not available" |
| 3 | forester.R | refuse `tune = TRUE`; tuning branches are not updated, and the paper never tuned |
| 4 | evaluate.R | keep model1..model4 = catboost, xgboost, ranger, lightgbm even when one fails |
| 5 | make_ranger.R | choose the P(goal) column by class value, not by position |
| 6 | make_xgboost.R | booster parameters via `params` (xgboost >= 2) |
| 7 | make_xgboost.R | don't attach fields to the booster (ALTREP object since xgboost 2.1) |
| 8 | make_lightgbm.R | learning rate via `params` (lightgbm >= 4 errors on loose arguments) |
| 9 | make_xgboost.R | `step_dummy()` on factor predictors only (recipes >= 1.0 errors on numerics) |

None of the patches changes a hyperparameter, the sampling, the split or a
metric definition. Model settings are the paper's: no tuning; ranger defaults
(500 trees); xgboost 20 rounds, defaults otherwise; lightgbm 10 rounds at
learning rate 0.4; catboost defaults.

forester is GPL-3; the paper's repository is MIT-licensed.
